"""
dd
"""

RESTAURANTS_DATA_URL = "https://raw.githubusercontent.com/Papagoat/brain-assessment/" \
                       "main/restaurant_data.json"
