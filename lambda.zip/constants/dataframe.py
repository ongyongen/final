"""
dddddd
"""

COUNTRY = "Country"
COUNTRY_CODE = "Country Code"
RESTAURANT_ID = "Restaurant Id"
RESTAURANT_NAME = "Restaurant Name"
COUNTRY = "Country"
CITY = "City"
USER_RATING_VOTES = "User Rating Votes"
USER_AGGREGATE_RATING = "User Aggregate Rating"
CUISINES = "Cuisines"
EVENTS = "Events"
COUNTRY_ID = "country_id"
RATING_TEXT = "rating_text"
EVENT_ID = "Event Id"
PHOTO_URL = "Photo URL"
EVENT_TITLE = "Event Title"
EVENT_START_DATE = "Event Start Date"
EVENT_END_DATE = "Event End Date"
EVENT_START_DATE_DT = "event_start_date_dt"
EVENT_END_DATE_DT = "event_end_date_dt"

NA_VALUE = "NA"
NUM_OF_EVENTS_COLUMNS = 7
EMPTY_EVENTS_CELL = []
