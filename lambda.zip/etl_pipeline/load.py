"""
dd
"""

def export_q1_dataframe_to_csv(q1_dataframe):
    """
    dd
    """
    q1_dataframe.to_csv("q1.csv")
    print("CSV file for Q1 is prepared")

def export_q2_dataframe_to_csv(q2_dataframe):
    """
    dd
    """
    q2_dataframe.to_csv("q2.csv")
    print("CSV file for Q2 is prepared")
